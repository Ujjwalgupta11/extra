#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import cfscrape
import re
from bs4 import BeautifulSoup
from ebooklib import epub
import json
import geocoder
import logging
import requests
import objectpath
import json
from ast import literal_eval
# Get the text at the set URL
scraper = cfscrape.create_scraper()


# In[131]:


a=[]
b=[]
c=[]
d=[]
e=[]
f=[]
baseurl="https://www.rumah123.com/en/rent/all-residential/?q=jakarta&page="
valid_pages = list(range(0,100,1))
for n in range(len(valid_pages)):
    urlPrefix = f'{baseurl}{valid_pages[n]}'
    print(urlPrefix)

    strpage = requests.get(urlPrefix)
    # Modifies the HTML received
    soup = BeautifulSoup(strpage.content, 'html5lib')
    for i in soup.find_all('script'):
        if type(i.text) == str and i.text.strip().startswith('window.__INITIAL_STATE'):
            t = i.text.strip()
            t = t[t.find('{'):]
            t = t[:1+t.rfind('}')]
            data=json.loads(t)
            break

    for i in range(0,len(data["listings"]["items"])):
        title=data["listings"]["items"][i]["title"]
        a.append(title)
        address=data["listings"]["items"][i]["address"]["formattedAddress"]
        b.append(address)
        if "lat" not in data["listings"]["items"][i]["address"].keys():
            lat="None"
        else:
            lat=data["listings"]["items"][i]["address"]["lat"]
        c.append(lat)
        if "lng" not in data["listings"]["items"][i]["address"].keys():
            lng="None"
        else:
            lng=data["listings"]["items"][i]["address"]["lng"]
        d.append(lng)

        if "level1" not in data["listings"]["items"][i]["multilanguagePlace"]["en-GB"].keys():
            level="None"
        else:
            level=data["listings"]["items"][i]["multilanguagePlace"]["en-GB"]["level1"]+","+data["listings"]["items"][i]["multilanguagePlace"]["en-GB"]["level2"]+","+data["listings"]["items"][i]["multilanguagePlace"]["en-GB"]["level3"]
        e.append(level)

        price=data["listings"]["items"][i]["prices"][0]["max"]
        f.append(price)
            

            
tmp= list([a,b,c,d,e,f])
final_df=pd.DataFrame(tmp).T
final_df2=pd.DataFrame()
final_df2["Title"]=final_df[0]
final_df2["Address"]=final_df[1]
final_df2["lat"]=final_df[2]
final_df2["lng"]=final_df[3]
final_df2["level"]=final_df[4]
final_df2["price"]=final_df[5]
final_df2.drop_duplicates()
final_df2.head()


# In[132]:


final_df2.shape


# In[133]:


original_index= final_df2.index


# In[134]:


location=[]
for idx in range(0,final_df2.shape[0]):
    if final_df2.loc[idx,"lat"]=='None':
        tmp=None
    else:
        tmp= str(final_df2.loc[idx,"lat"])+","+str(final_df2.loc[idx,"lng"])
    location.append(tmp) 
    
final_df2["location"]= location


# In[135]:


final_df2["location"]


# In[31]:


# final_df2.reset_index(inplace=True)


# In[55]:


# final_df2.drop(["location","Zip_code"], axis=1, inplace=True)


# In[115]:


#final_df2[:50].loc[-final_df2.location.isna(),"location"].apply(lambda x: zip_code_cn(x))


# In[136]:


from geopy.geocoders import Nominatim
from geopy.exc import GeocoderTimedOut
import time
geolocator = Nominatim(user_agent="ashish",timeout=None)
loc_index= final_df2.loc[-final_df2.location.isna(),"location"].index


# In[137]:


def zip_code_cn(x):
    loc=geolocator.reverse(x)
    time.sleep(0.5)
    return loc

# final_df2.loc[final_df2[6:10].index, "Zip_code"]=final_df2[6:10].loc[-final_df2.location.isna(),"location"].apply(lambda x: zip_code_cn(x))


# In[178]:


final_df2["Complete_Address"]= None


# In[139]:


final_df2_1= final_df2.loc[loc_index,]


# In[140]:


Zip_code = final_df2_1.location.apply(lambda x: zip_code_cn(x))


# In[177]:


Zip_code= Zip_code.apply(lambda x: x[0])


# In[179]:


final_df2.loc[Zip_code.index,"Complete_Address"]=Zip_code


# In[183]:


final_df2["Zip_code"]= final_df2.Complete_Address.str.extract(r"(\d{5})")


# In[187]:


final_df2


# In[186]:


final_df2.to_csv("C:/Users/lokesh_pc/Hidden_Preffered_Project_Indonesia/Hidden_pref_Rent.csv",index=False)

