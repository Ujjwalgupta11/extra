
import re
import requests
import pandas as pd
from time import sleep
from random import randint


property_df = pd.DataFrame()
n_pages = 0


headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
}
n_properties= 0
for page in range(0,10):
    n_pages += 1
    lamudi_url = 'https://www.lamudi.com.ph/buy/?page='+str(page)
    page_html = requests.get(lamudi_url, headers=headers).text
    soup = BeautifulSoup(page_html, 'html.parser')
    house_containers = soup.find_all('div', class_="row ListingCell-row")
    if house_containers != []:
        n_properties += len(house_containers)
        for container in house_containers:
            property_dict = {"ADDRESS":None, "PRICE":None, "BEDROOMS":None, "BATHS":None, "FLOOR AREA":None, "LAND SIZE":None}
            p_label_list= []
            address= "ADDRESS"
            price= "PRICE"
            others= [i.text.strip().upper() for i in container.find_all('span', class_="KeyInformation-label_v2")]
            p_label_list.append(address)
            p_label_list.append(price)
            p_label_list.extend(others)
            
            p_values_list= []
            try:
                address= " ".join(x for x in re.sub(r"[^a-zA-Z0-9,.]"," ",container.find_all('span', class_="")[0].text).split())
            except IndexError:
                address= "NA"
            try:
                price= container.find_all('span', class_="PriceSection-FirstPrice")[0].text.strip()
            except IndexError:
                price= "NA"
            others= [i.text.strip() for i in container.find_all('span', class_="KeyInformation-value_v2")]
            p_values_list.append(address)
            p_values_list.append(price)
            p_values_list.extend(others)

            for key,value in zip(p_label_list,p_values_list):
                property_dict[key]=value
                
            property_df = property_df.append(property_dict, ignore_index=True)
            
    else:
        break
    
    #print(page)
 #   sleep(randint(1,2))
    
#print('You scraped {} pages containing {} properties.'.format(n_pages, n_properties))
property_df.to_csv('property_details.csv', index = False)