#!/usr/bin/env python
# coding: utf-8

# In[1]:


import cfscrape
import re
from bs4 import BeautifulSoup
from ebooklib import epub
import json
import geocoder
import logging
import requests
import objectpath
import json
from ast import literal_eval
import pandas as pd
# Get the text at the set URL
scraper = cfscrape.create_scraper()


# In[2]:


city_list=['Surabaya','Tangerang','Medan','Bandung','Bekasi','Bogor','Semarang','Malang','Depok','Denpasar',
           'Surakarta','Makassar']
for i in city_list:
    baseurl="https://www.rumah123.com/en/sale/all-residential/?minPrice=100000000&q="+str(i)+"&page="
    valid_pages = list(range(0,1,1))
    for n in range(len(valid_pages)):
        urlPrefix = f'{baseurl}{valid_pages[n]}'
        print(urlPrefix)   


# In[14]:


a=[]
b=[]
c=[]
d=[]
e=[]
f=[]
g=[]
h=[]
Final_ab=pd.DataFrame(columns=['Address', 'lat', 'lng', 'price', 'Installment', 'level', 'title', 'city'])
city_list=['Surabaya','Tangerang','Medan','Bandung','Bekasi','Bogor','Semarang','Malang','Depok','Denpasar',
           'Surakarta','Makassar']
for city in city_list:
    baseurl="https://www.rumah123.com/en/sale/all-residential/?minPrice=100000000&q="+str(city)+"&page="
    valid_pages = list(range(0,100,1))
    for n in range(len(valid_pages)):
        urlPrefix = f'{baseurl}{valid_pages[n]}'
        print(urlPrefix)   

        strpage = requests.get(urlPrefix)
        # Modifies the HTML received
        soup = BeautifulSoup(strpage.content, 'html5lib')
        for i in soup.find_all('script'):
            if type(i.text) == str and i.text.strip().startswith('window.__INITIAL_STATE'):
                t = i.text.strip()
                t = t[t.find('{'):]
                t = t[:1+t.rfind('}')]
                data=json.loads(t)
                break

        for i in range(0,len(data["listings"]["items"])):
            address=data["listings"]["items"][i]["address"]["formattedAddress"]
            a.append(address)
            if "lat" not in data["listings"]["items"][i]["address"].keys():
                lat="None"
            else:
                lat=data["listings"]["items"][i]["address"]["lat"]
            b.append(lat)
            if "lng" not in data["listings"]["items"][i]["address"].keys():
                lng="None"
            else:
                lng=data["listings"]["items"][i]["address"]["lng"]
            c.append(lng)

            price=data["listings"]["items"][i]["prices"][0]["max"]
            d.append(price)
            if "monthlyPayment" not in data["listings"]["items"][i]["prices"][0].keys():
                installment="None"
            else:
                installment=data["listings"]["items"][i]["prices"][0]["monthlyPayment"]
            e.append(installment)

            if "level1" not in data["listings"]["items"][i]["multilanguagePlace"]["en-GB"].keys():
                level="None"
            else:
                level=data["listings"]["items"][i]["multilanguagePlace"]["en-GB"]["level1"]+","+data["listings"]["items"][i]["multilanguagePlace"]["en-GB"]["level2"]+","+data["listings"]["items"][i]["multilanguagePlace"]["en-GB"]["level3"]
            f.append(level)

            title=data["listings"]["items"][i]["title"]
            g.append(title)
            
            h.append(city)
            
            
    tmp= list([a,b,c,d,e,f,g,h])
    final_df=pd.DataFrame(tmp).T
    final_df2=pd.DataFrame()
    final_df2["Address"]=final_df[0]
    final_df2["lat"]=final_df[1]
    final_df2["lng"]=final_df[2]
    final_df2["price"]=final_df[3]
    final_df2["Installment"]=final_df[4]
    final_df2["level"]=final_df[5]
    final_df2["title"]=final_df[6]
    final_df2["city"]=final_df[7]
    Final_ab= pd.concat([Final_ab,final_df2], axis=0)
Final_ab.drop_duplicates()
Final_ab.head()


# In[ ]:


Final_ab.shape


# In[ ]:


Final_ab.to_csv("Final_Data_All_Cities.csv",index=False)


# In[4]:


original_index= final_df2.index


# In[5]:


len(data["listings"]["items"])


# In[15]:


# data["listings"]["items"][0]["multilanguagePlace"]["en-GB"]


# In[17]:


# data["listings"]["items"][0]["title"]


# In[6]:


# data["listings"]["items"][1]


# In[ ]:


# i=12
# address=data["listings"]["items"][i]["address"]["formattedAddress"]
# lat=data["listings"]["items"][i]["address"]["lat"]
# lng=data["listings"]["items"][i]["address"]["lng"]
# print(address,"DONE",lat,"DONE",lng,"DONE")


# In[ ]:


# address=data["listings"]["items"][18]["address"]["formattedAddress"]
# lat=data["listings"]["items"][18]["address"]["lat"]
# lng=data["listings"]["items"][18]["address"]["lng"]
# currency=data["listings"]["items"][18]["prices"][0]["currency"]
# price=data["listings"]["items"][18]["prices"][0]["max"]
# installment=data["listings"]["items"][18]["prices"][0]["monthlyPayment"]


# In[7]:


# data


# In[8]:


final_df2.head(10)


# In[9]:


location=[]
for idx in range(0,final_df2.shape[0]):
    if final_df2.loc[idx,"lat"]=='None':
        tmp=None
    else:
        tmp= str(final_df2.loc[idx,"lat"])+","+str(final_df2.loc[idx,"lng"])
    location.append(tmp) 
    
final_df2["location"]= location


# In[24]:


from geopy.geocoders import Nominatim
from geopy.exc import GeocoderTimedOut
import time
geolocator = Nominatim(user_agent="ashish",timeout=None)
loc_index= final_df2.loc[-final_df2.location.isna(),"location"].index


# In[25]:


def zip_code_cn(x):
    loc=geolocator.reverse(x)
    time.sleep(0.5)
    return loc


# In[26]:


final_df2["Complete_Address"]= None
final_df2_1= final_df2.loc[loc_index,]


# In[28]:


Zip_code = final_df2_1.location.apply(lambda x: zip_code_cn(x))


# In[29]:


Zip_code


# In[30]:


Zip_code= Zip_code.apply(lambda x: x[0])
final_df2.loc[Zip_code.index,"Complete_Address"]=Zip_code
final_df2["Zip_code"]= final_df2.Complete_Address.str.extract(r"(\d{5})")


# In[31]:


pd.options.display.max_columns=None
pd.set_option('display.max_rows',500)
pd.set_option('display.max_columns',500)
pd.set_option('display.width',1000)


# In[32]:


final_df2.head()


# In[33]:


final_df2.to_csv("C:/Users/lokesh_pc/Hidden_Preffered_Project_Indonesia/Hidden_pref_sale.csv",index=False)


# In[15]:


final_df2.shape


# In[34]:


final_df2.Zip_code.isnull().sum()


# In[36]:


import os


# In[38]:


os.getcwd()


# In[ ]:




